﻿using UnityEngine;
public class ReadOnlyWhenPlayingAttribute : PropertyAttribute { }
